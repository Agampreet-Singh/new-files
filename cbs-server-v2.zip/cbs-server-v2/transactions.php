<?php
require 'includes/auth.php';
require 'config.php';
$filter = $_GET['status'] ?? '';
$sql = "SELECT * FROM transactions";
$params = [];
if (in_array($filter, ['approved','declined'])) { $sql .= " WHERE status=?"; $params[] = $filter; }
$sql .= " ORDER BY created_at DESC LIMIT 300";
$stmt = $pdo->prepare($sql); $stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
require 'includes/header.php';
?>
<div style="display:flex;gap:8px;margin-bottom:20px;">
  <a href="transactions.php" class="btn btn-outline btn-sm <?= !$filter?'btn-primary':'' ?>">All</a>
  <a href="transactions.php?status=approved" class="btn btn-outline btn-sm <?= $filter==='approved'?'btn-primary':'' ?>">Approved</a>
  <a href="transactions.php?status=declined" class="btn btn-outline btn-sm <?= $filter==='declined'?'btn-primary':'' ?>">Declined</a>
</div>
<div class="panel">
  <div class="panel-header">
    <h3>Transaction Log</h3>
    <span class="panel-badge"><?= count($transactions) ?> records</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Card Number</th><th>Channel</th><th>Type</th><th>Amount</th><th>Balance After</th><th>Status</th><th>Reason</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($transactions as $tx): ?>
        <tr>
          <td style="color:#6b7a8a;"><?= $tx['id'] ?></td>
          <td><code style="background:#f0f2f5;padding:2px 8px;border-radius:4px;font-size:11.5px;"><?= htmlspecialchars($tx['card_number']) ?></code></td>
          <td><?= htmlspecialchars($tx['atm_id']) ?></td>
          <td style="font-size:12.5px;"><?= htmlspecialchars($tx['txn_type'] ?? 'withdrawal') ?></td>
          <td><strong>Rs.<?= number_format($tx['amount'],2) ?></strong></td>
          <td style="color:#6b7a8a;"><?= isset($tx['balance_after']) ? 'Rs.'.number_format($tx['balance_after'],2) : 'N/A' ?></td>
          <td><span class="badge badge-<?= $tx['status'] ?>"><?= ucfirst($tx['status']) ?></span></td>
          <td style="color:#6b7a8a;font-size:12px;"><?= htmlspecialchars($tx['reason']) ?></td>
          <td style="color:#6b7a8a;font-size:12px;"><?= date('d M, h:i A', strtotime($tx['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
