<?php
require 'includes/auth.php';
require 'config.php';

$message = $msg_type = "";

// ---- ACTION: Add / Update Card (with optional new customer creation) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_card') {
    $card_number = trim($_POST['card_number']);
    $pin_hash    = password_hash(trim($_POST['pin']), PASSWORD_BCRYPT);
    $balance     = floatval($_POST['balance']);
    $status      = $_POST['status'];
    $customer_id = null;

    // Decide customer: link existing, or create new
    if (!empty($_POST['customer_id'])) {
        $customer_id = intval($_POST['customer_id']);
    } elseif (!empty(trim($_POST['new_full_name']))) {
        // Create a new customer row on the fly
        $stmt = $pdo->prepare("INSERT INTO customers (full_name,email,phone,kyc_id,branch) VALUES (?,?,?,?,?)");
        $stmt->execute([
            trim($_POST['new_full_name']),
            trim($_POST['new_email']),
            trim($_POST['new_phone']),
            trim($_POST['new_kyc_id']),
            trim($_POST['new_branch'])
        ]);
        $customer_id = $pdo->lastInsertId();
    }

    // Insert or update the card
    $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_number=?");
    $stmt->execute([$card_number]);
    if ($stmt->fetch()) {
        $pdo->prepare("UPDATE cards SET pin=?,balance=?,status=?,customer_id=? WHERE card_number=?")
            ->execute([$pin_hash, $balance, $status, $customer_id, $card_number]);
        $message = "Card $card_number updated successfully.";
    } else {
        $pdo->prepare("INSERT INTO cards (customer_id,card_number,pin,balance,status) VALUES (?,?,?,?,?)")
            ->execute([$customer_id, $card_number, $pin_hash, $balance, $status]);
        $message = "Card $card_number issued successfully.";
    }
    $msg_type = "success";
}

// ---- ACTION: Delete Card by card number ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_card') {
    $del_card = trim($_POST['delete_card_number']);
    $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_number=?");
    $stmt->execute([$del_card]);
    if ($stmt->fetch()) {
        $pdo->prepare("DELETE FROM cards WHERE card_number=?")->execute([$del_card]);
        $message = "Card $del_card has been removed.";
        $msg_type = "success";
    } else {
        $message = "Card $del_card not found.";
        $msg_type = "error";
    }
}

// ---- Data ----
$cards = $pdo->query("
    SELECT cd.*, c.full_name, c.email, c.branch
    FROM cards cd LEFT JOIN customers c ON c.id=cd.customer_id
    ORDER BY cd.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$customers = $pdo->query("SELECT id,full_name FROM customers ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);
$total_cards  = count($cards);
$active_cards = count(array_filter($cards, fn($c) => $c['status']==='active'));
$total_bal    = array_sum(array_column($cards,'balance'));

require 'includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-<?= $msg_type === 'success' ? 'success' : 'error' ?>">
  <?= htmlspecialchars($message) ?>
</div>
<?php endif; ?>

<!-- Stats -->
<div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
  <div class="stat-card">
    <div class="label">Total Cards</div>
    <div class="value"><?= $total_cards ?></div>
    <div class="trend"><?= $active_cards ?> active</div>
  </div>
  <div class="stat-card">
    <div class="label">Blocked Cards</div>
    <div class="value"><?= $total_cards - $active_cards ?></div>
  </div>
  <div class="stat-card">
    <div class="label">Total Balance (Active)</div>
    <div class="value">Rs.<?= number_format($total_bal,0) ?></div>
  </div>
</div>

<!-- Tabs -->
<div class="tabs">
  <button class="tab active" onclick="showTab('tab-issue')">Issue / Update Card</button>
  <button class="tab" onclick="showTab('tab-delete')">Remove Card</button>
  <button class="tab" onclick="showTab('tab-list')">All Cards (<?= $total_cards ?>)</button>
</div>

<!-- TAB 1: Issue / Update Card -->
<div id="tab-issue" class="panel">
  <div class="panel-header">
    <h3>Issue / Update Card</h3>
    <span class="panel-badge">New customer auto-created if name is filled</span>
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="save_card">
    <div class="form-grid">
      <!-- Card details section -->
      <div class="form-section-title">Card Details</div>
      <div class="field">
        <label>Card Number *</label>
        <input type="text" name="card_number" placeholder="4000123456789999" maxlength="20" required>
      </div>
      <div class="field">
        <label>PIN (4 digits) *</label>
        <input type="text" name="pin" maxlength="4" placeholder="1234" required>
      </div>
      <div class="field">
        <label>Opening Balance (Rs.) *</label>
        <input type="number" step="0.01" name="balance" placeholder="50000.00" required>
      </div>
      <div class="field">
        <label>Status</label>
        <select name="status">
          <option value="active">Active</option>
          <option value="blocked">Blocked</option>
        </select>
      </div>

      <!-- Link to existing customer -->
      <div class="form-section-title">Link to Customer</div>
      <div class="field" style="grid-column:1/-1;">
        <label>Select Existing Customer (optional)</label>
        <select name="customer_id" style="max-width:360px;">
          <option value="">— None / Enter new customer below —</option>
          <?php foreach ($customers as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- New customer -->
      <div class="form-section-title">Or Create New Customer</div>
      <div class="field">
        <label>Full Name</label>
        <input type="text" name="new_full_name" placeholder="Ramesh Kulkarni">
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" name="new_email" placeholder="ramesh@example.com">
      </div>
      <div class="field">
        <label>Phone</label>
        <input type="text" name="new_phone" placeholder="9822011111" maxlength="15">
      </div>
      <div class="field">
        <label>KYC ID</label>
        <input type="text" name="new_kyc_id" placeholder="KYC10006">
      </div>
      <div class="field">
        <label>Branch</label>
        <input type="text" name="new_branch" placeholder="Head Office">
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Save Card</button>
      </div>
    </div>
  </form>
</div>

<!-- TAB 2: Delete Card -->
<div id="tab-delete" class="panel" style="display:none;">
  <div class="panel-header">
    <h3>Remove Card</h3>
    <span class="panel-badge" style="background:#fef0f0;color:#c0392b;">Irreversible action</span>
  </div>
  <form method="POST" onsubmit="return confirm('Are you sure you want to permanently delete this card?');">
    <input type="hidden" name="action" value="delete_card">
    <div class="form-grid-2" style="max-width:600px;">
      <div class="field">
        <label>Card Number to Remove *</label>
        <input type="text" name="delete_card_number" placeholder="4000123456789999" required>
      </div>
      <div class="field" style="justify-content:flex-end;">
        <label>&nbsp;</label>
        <button type="submit" class="btn btn-danger">Remove Card</button>
      </div>
    </div>
  </form>

  <!-- Quick remove from list -->
  <div style="margin-top:28px;">
    <div class="panel-header">
      <h3 style="font-size:13.5px; color:#6b7a8a;">Or click to remove from card list below</h3>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Card Number</th><th>Customer</th><th>Balance</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach ($cards as $c): ?>
          <tr>
            <td><code style="background:#f0f2f5;padding:3px 8px;border-radius:4px;font-size:12px;"><?= htmlspecialchars($c['card_number']) ?></code></td>
            <td><?= htmlspecialchars($c['full_name'] ?? 'No customer') ?></td>
            <td>Rs.<?= number_format($c['balance'],2) ?></td>
            <td><span class="badge badge-<?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete card <?= htmlspecialchars($c['card_number']) ?>?');">
                <input type="hidden" name="action" value="delete_card">
                <input type="hidden" name="delete_card_number" value="<?= htmlspecialchars($c['card_number']) ?>">
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- TAB 3: All Cards -->
<div id="tab-list" class="panel" style="display:none;">
  <div class="panel-header">
    <h3>All Cards</h3>
    <span class="panel-badge"><?= $total_cards ?> total</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Card Number</th><th>Customer</th><th>Email</th><th>Branch</th><th>Balance</th><th>Status</th><th>Issued</th></tr></thead>
      <tbody>
        <?php foreach ($cards as $c): ?>
        <tr>
          <td><code style="background:#f0f2f5;padding:3px 8px;border-radius:4px;font-size:12px;"><?= htmlspecialchars($c['card_number']) ?></code></td>
          <td><?= htmlspecialchars($c['full_name'] ?? '—') ?></td>
          <td style="color:#6b7a8a;font-size:12px;"><?= htmlspecialchars($c['email'] ?? '—') ?></td>
          <td><?= htmlspecialchars($c['branch'] ?? '—') ?></td>
          <td><strong>Rs.<?= number_format($c['balance'],2) ?></strong></td>
          <td><span class="badge badge-<?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
          <td style="color:#6b7a8a;font-size:12px;"><?= date('d M Y', strtotime($c['issued_date'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function showTab(id) {
  ['tab-issue','tab-delete','tab-list'].forEach(t => {
    document.getElementById(t).style.display = t===id ? 'block' : 'none';
  });
  document.querySelectorAll('.tab').forEach((btn,i) => {
    btn.classList.toggle('active', ['tab-issue','tab-delete','tab-list'][i]===id);
  });
}
</script>

<?php require 'includes/footer.php'; ?>
