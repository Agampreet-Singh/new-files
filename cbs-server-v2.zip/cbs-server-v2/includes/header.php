<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cosmos Bank CBS — Admin Portal</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-mark">CB</div>
      <div>
        <div class="brand-name">Cosmos Bank</div>
        <div class="brand-sub">Core Banking System</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">
        <span class="nav-icon">&#9632;</span> Dashboard
      </a>
      <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>">
        <span class="nav-icon">&#9632;</span> Customers
      </a>
      <a href="cards.php" class="<?= basename($_SERVER['PHP_SELF'])=='cards.php'?'active':'' ?>">
        <span class="nav-icon">&#9632;</span> Cards
      </a>
      <a href="transactions.php" class="<?= basename($_SERVER['PHP_SELF'])=='transactions.php'?'active':'' ?>">
        <span class="nav-icon">&#9632;</span> Transactions
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="logout.php" class="logout-link">
        <span>&#9632;</span> Log out
      </a>
    </div>
  </aside>
  <div class="content">
    <div class="topbar">
      <div>
        <div class="topbar-title"><?php
          $titles = ['dashboard.php'=>'Dashboard','customers.php'=>'Customers','cards.php'=>'Cards & Accounts','transactions.php'=>'Transaction Log'];
          echo $titles[basename($_SERVER['PHP_SELF'])] ?? 'CBS Portal';
        ?></div>
        <div class="topbar-sub">Cosmos Co-operative Bank — Core Banking System</div>
      </div>
      <div class="admin-badge">
        <div class="admin-avatar"><?= strtoupper(substr($_SESSION['admin_name'],0,1)) ?></div>
        <div class="admin-name"><?= htmlspecialchars($_SESSION['admin_name']) ?></div>
      </div>
    </div>
    <div class="main-body">
