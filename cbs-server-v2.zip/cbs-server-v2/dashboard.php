<?php
require 'includes/auth.php';
require 'config.php';

$totalCustomers = $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$totalCards     = $pdo->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$activeCards    = $pdo->query("SELECT COUNT(*) FROM cards WHERE status='active'")->fetchColumn();
$totalBalance   = $pdo->query("SELECT COALESCE(SUM(balance),0) FROM cards WHERE status='active'")->fetchColumn();
$todayTx        = $pdo->query("SELECT COUNT(*) FROM transactions WHERE DATE(created_at)=CURDATE()")->fetchColumn();
$approvedTx     = $pdo->query("SELECT COUNT(*) FROM transactions WHERE status='approved'")->fetchColumn();

$recent = $pdo->query("SELECT * FROM transactions ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

require 'includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="label">Total Customers</div>
    <div class="value"><?= $totalCustomers ?></div>
    <div class="trend">Registered members</div>
  </div>
  <div class="stat-card">
    <div class="label">Active Cards</div>
    <div class="value"><?= $activeCards ?></div>
    <div class="trend"><?= $totalCards - $activeCards ?> blocked</div>
  </div>
  <div class="stat-card">
    <div class="label">Total Balance</div>
    <div class="value">Rs.<?= number_format($totalBalance,0) ?></div>
    <div class="trend">Across active cards</div>
  </div>
  <div class="stat-card">
    <div class="label">Transactions Today</div>
    <div class="value"><?= $todayTx ?></div>
    <div class="trend"><?= $approvedTx ?> approved total</div>
  </div>
</div>

<div class="panel">
  <div class="panel-header">
    <h3>Recent Transactions</h3>
    <a href="transactions.php" class="btn btn-outline btn-sm">View All</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Card Number</th><th>Channel</th><th>Amount</th><th>Status</th><th>Reason</th><th>Time</th></tr></thead>
      <tbody>
        <?php foreach ($recent as $tx): ?>
        <tr>
          <td><code style="background:#f0f2f5;padding:3px 8px;border-radius:4px;font-size:12px;"><?= htmlspecialchars($tx['card_number']) ?></code></td>
          <td><?= htmlspecialchars($tx['atm_id']) ?></td>
          <td><strong>Rs.<?= number_format($tx['amount'],2) ?></strong></td>
          <td><span class="badge badge-<?= $tx['status'] ?>"><?= ucfirst($tx['status']) ?></span></td>
          <td style="color:#6b7a8a;font-size:12.5px;"><?= htmlspecialchars($tx['reason']) ?></td>
          <td style="color:#6b7a8a;font-size:12px;"><?= date('d M, h:i A', strtotime($tx['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($recent)): ?>
        <tr><td colspan="6" style="text-align:center;color:#8a9a9a;padding:32px;">No transactions yet</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
