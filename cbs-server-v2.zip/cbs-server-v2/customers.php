<?php
require 'includes/auth.php';
require 'config.php';
$customers = $pdo->query("
    SELECT c.*, COUNT(cd.id) as card_count,
           GROUP_CONCAT(cd.card_number SEPARATOR ', ') AS cards
    FROM customers c LEFT JOIN cards cd ON cd.customer_id=c.id
    GROUP BY c.id ORDER BY c.id DESC
")->fetchAll(PDO::FETCH_ASSOC);
require 'includes/header.php';
?>
<div class="panel">
  <div class="panel-header">
    <h3>All Customers</h3>
    <span class="panel-badge"><?= count($customers) ?> registered</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>KYC ID</th><th>Branch</th><th>Cards</th></tr></thead>
      <tbody>
        <?php foreach ($customers as $c): ?>
        <tr>
          <td style="color:#6b7a8a;">#<?= $c['id'] ?></td>
          <td><strong><?= htmlspecialchars($c['full_name']) ?></strong></td>
          <td style="color:#6b7a8a;font-size:12.5px;"><?= htmlspecialchars($c['email'] ?? '—') ?></td>
          <td><?= htmlspecialchars($c['phone'] ?? '—') ?></td>
          <td><code style="background:#f0f2f5;padding:2px 8px;border-radius:4px;font-size:12px;"><?= htmlspecialchars($c['kyc_id'] ?? '—') ?></code></td>
          <td><?= htmlspecialchars($c['branch'] ?? '—') ?></td>
          <td style="font-size:12px;color:#1a6fa8;"><?= htmlspecialchars($c['cards'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require 'includes/footer.php'; ?>
