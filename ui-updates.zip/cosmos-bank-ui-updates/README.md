# Cosmos Bank Lab - UI Updates Package

This package has two independent updates:

1. **`reg-atms/atm_app.py`** - redesigned ATM kiosk screen (blue theme, real card-insert
   animation with PIN pad on the left and card slot on the right, international flags
   on the Hong Kong ATM only). Fully tested end-to-end against the ATM Switch.
2. **`cosmos-ibank-portal/`** - Contact Us page now shows `admin@cosmosbank.in` in a
   large banner right under the page title, not just buried in a card.

Everything is plain ASCII text (no emoji, no smart quotes/dashes) so it is safe to
copy-paste through a terminal (`nano`, etc.) without corruption.

---

## PART 1 - ATM kiosk redesign (Reg. ATMs machine, 10.25.0.8)

### What changed
- Color theme: dark green -> **dark blue**, with gold accents kept for a premium bank feel
- The old separate "Insert Card" screen and "PIN" screen are now **one combined screen**:
  left half is the PIN keypad (greyed out and disabled until a card is "inserted"),
  right half is a card slot with a card graphic that **slides up and disappears into the
  slot** when you press Insert Card - just like a real ATM eating your card
- Added a small circular Cosmos Bank logo mark in the top bar (matches the main website's logo)
- Added rounded checkmark/cross icons (drawn as SVG, not emoji) for the approved/declined
  and "take card" screens
- **Hong Kong ATM only**: shows "HONGKONG ATM - INTERNATIONAL" in the header plus a row of
  5 flags (India, Hong Kong, USA, UK, Singapore) drawn in pure CSS - no image files, no
  emoji, so nothing to corrupt during copy-paste
- All other functionality (withdraw, deposit, balance inquiry, mini statement, PIN retry
  limit, ENTER button) is unchanged from the last working version

### Deploy steps
```bash
sudo systemctl stop atm-pune atm-mumbai atm-hongkong
```
Replace `/opt/reg-atms/atm_app.py` with the new file from this package (either copy it
over directly if you can transfer files, or open with `sudo nano /opt/reg-atms/atm_app.py`,
delete everything, and paste the new content in).

```bash
sudo systemctl start atm-pune atm-mumbai atm-hongkong
sudo systemctl status atm-pune atm-mumbai atm-hongkong
```
All three should show `active (running)`. No changes are needed to the systemd service
files, the ATM Switch, or CBS Server for this update - it only touches the kiosk's own
look and feel.

### Test it
1. Open `http://10.25.0.8:8001/` (Pune) - confirm the blue theme and the split
   PIN/card-slot layout
2. Type a card number (e.g. `4000123456781001`) and press **Insert Card** - watch the
   card graphic slide up into the slot and disappear; the PIN keypad on the left should
   light up (no longer greyed out)
3. Enter PIN `1234` - it should auto-submit on the 4th digit (or press ENTER manually)
   and take you to the menu
4. Open `http://10.25.0.8:8003/` (Hong Kong) - confirm the header says
   "HONGKONG ATM - INTERNATIONAL" and 5 country flags are visible under the top bar

---

## PART 2 - Contact page update (Bank Admin machine / CBS Server, wherever the
Cosmos iBank site is hosted)

### What changed
`contact.html` now has a large teal banner directly under the "Contact Us" heading,
showing `admin@cosmosbank.in` in big bold text - it's the first thing a visitor sees
on the page, not something they have to scroll or search for inside a card.

### Deploy steps
Copy both `index.html` and `contact.html` from `cosmos-ibank-portal/` in this package
into the same folder where the website is currently hosted (e.g.
`C:\xampp\htdocs\cosmosbank\`), overwriting the existing files.

Reload the page in the browser (`http://localhost/cosmosbank/contact.html`) - the
banner should appear right below the page header.

---

## PART 3 - Detailed mini statement (CBS Server + ATM Switch)

### What changed
Mini Statement used to show only ATM, amount, and status. It now shows, per
transaction: **ATM Info, Date & Time, Card Number, Transaction Type, Transaction
Date, Transaction Amount, Credit/Debit indicator, Status, and Available Balance**
- exactly like a real bank statement entry.

This needed two small additions:
- `transactions` table gets two new columns: `txn_type` (withdrawal/deposit) and
  `balance_after` (the balance right after that transaction)
- The ATM Switch now saves both of these on every withdraw/deposit, and returns
  them (plus a computed Credit/Debit indicator) when a mini statement is requested

Old transactions from before this update will show "Withdrawal" (a safe default,
since withdrawals were the only type that existed before) and "N/A" for balance,
since that information wasn't being tracked yet.

### Deploy steps

**1. CBS Server** - phpMyAdmin > SQL tab, run `atm-switch/cbs_add_statement_columns.sql`:
```sql
ALTER TABLE cosmos_bank.transactions
  ADD COLUMN txn_type VARCHAR(20) NULL AFTER atm_id,
  ADD COLUMN balance_after DECIMAL(14,2) NULL AFTER amount;
```

**2. ATM Switch (10.24.0.5)** - replace `/opt/atm-switch/atm_switch_service.py` with
the updated file in `atm-switch/atm_switch_service.py` from this package, then:
```bash
sudo systemctl restart atm-switch
```
(The default password in the file is already set to `AtmSwitch2024Secure` - double
check it matches whatever you actually set on your `atmswitch` MySQL user.)

**3. Reg. ATMs (10.25.0.8)** - the `atm_app.py` in Part 1 of this package already
includes the new detailed mini-statement screen, so no separate step is needed here
if you're deploying Part 1 and Part 3 together.

### Test it
Do a withdrawal and a deposit on any ATM, then open Mini Statement - each entry
should show all nine fields listed above, with Credit shown in green and Debit in
red (matching money coming in vs going out).

---


- None of these changes affect the attack chain - the ATM redesign is purely cosmetic/UX
  (same `/api/action` endpoint and JSON contract with the ATM Switch), and the contact
  page change just makes the OSINT step of the Red Teamer's phishing recon
  (finding `admin@cosmosbank.in`) more obviously visible for anyone watching the
  exercise or reviewing the site for the first time.
