<?php
// Minimal target page for the PHP2Shell lab.
// PHP2Shell lives in the runtime (request parsing, sessions, OOM handling),
// so the app itself does almost nothing on purpose.
session_start();
$_SESSION['hits'] = ($_SESSION['hits'] ?? 0) + 1;

header('Content-Type: text/plain');
echo "PHP version:                    " . PHP_VERSION . "\n";
echo "SAPI:                           " . PHP_SAPI . "\n";
echo "memory_limit:                   " . ini_get('memory_limit') . "\n";
echo "session.upload_progress.enabled:" . (ini_get('session.upload_progress.enabled') ? ' 1' : ' 0') . "\n";
echo "file_uploads:                   " . (ini_get('file_uploads') ? '1' : '0') . "\n";
echo "post_max_size:                  " . ini_get('post_max_size') . "\n";
echo "Session hits:                   " . $_SESSION['hits'] . "\n";
