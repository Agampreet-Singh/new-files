# PHP2Shell Lab (CVE-2026-109618 / CVE-2026-109619)

Local, isolated lab for studying PHP2Shell: two memory-safety bugs in the PHP runtime that can give
unauthenticated RCE on any server handling PHP web requests (mod_php, PHP-FPM, php-cgi, LiteSpeed, FrankenPHP).

| Container              | URL                    | PHP     | Purpose                          |
|------------------------|------------------------|---------|----------------------------------|
| php2shell-vulnerable   | http://127.0.0.1:8081  | 8.4.26  | Unpatched baseline               |
| php2shell-mitigated    | http://127.0.0.1:8082  | 8.4.26  | Unpatched + interim php.ini fixes|
| php2shell-patched      | http://127.0.0.1:8083  | 8.4.27  | Fixed release                    |

## The two bugs, briefly

- **CVE-2026-109618 — RCE via OOM corruption.** PHP aborts fatal errors (including out-of-memory) with
  `longjmp()`. If memory runs out while a request is only half-parsed (e.g. multipart → `$_POST`/`$_FILES`),
  cleanup later treats partially-initialised memory as valid.
- **CVE-2026-109619 — RCE via stale global state.** Global state (session upload progress, error
  backtraces, etc.) owned by one request can outlive its freed memory. The next request on the *same worker*
  touches the stale pointer → use-after-free.

Fixed in **8.5.12, 8.4.27, 8.3.36, 8.2.35**. PHP states no config change fully closes it.

## Run it

```bash
cd php2shell-lab
docker compose pull
docker compose up -d
curl -s http://127.0.0.1:8081/   # vulnerable
curl -s http://127.0.0.1:8082/   # mitigated
curl -s http://127.0.0.1:8083/   # patched
```

Each page prints the PHP version, SAPI, `memory_limit` and `session.upload_progress.enabled`, so you can
confirm the three targets differ the way you expect.

> If `php:8.4.26-apache` has been pulled from Docker Hub, pin it by digest from a mirror you trust, or build
> 8.4.26 from the php-src tag. Don't use random "vulnerable image" repos.

## Exercises

1. **Version fingerprinting** – confirm which containers your scanner (Qualys QID 520310, Nuclei, Aikido
   checker, `php -v` inside the container) flags as vulnerable. Note the CLI `php` binary can differ from the
   one Apache runs.
2. **Mitigation verification** – diff `phpinfo()` / the index page between 8081 and 8082.
3. **Detection engineering** – the logged requests in `logs/*/access.log` are your evidence source. Look for
   oversized multipart bodies, requests carrying `PHP_SESSION_UPLOAD_PROGRESS`, bursts of 500s, and
   `child pid ... exit signal Segmentation fault` lines in `error.log`. Write Sigma/WAF rules from these.
4. **Patch validation** – any PoC you test should crash/succeed on 8081 and fail cleanly on 8083.
5. **Incident response** – practise capturing volatile evidence (`docker exec … ps`, core dumps) *before*
   restarting workers, since a restart wipes the state CVE-2026-109619 abuses.

## Safety

- Ports bind to `127.0.0.1` only. Run it on a throwaway VM; don't expose it.
- Public "PHP2Shell PoC" repos are untrusted code — several are fake or backdoored. Read before running,
  and run only inside the VM.
- Tear down: `docker compose down -v`
