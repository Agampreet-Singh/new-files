<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="input.css">
</head>
<body class="bg-maastrichtBlue">
    <!-- Navbar -->
    <?php
        $ipAddress = exec("/sbin/ifconfig enp0s3 | grep 'inet ' | awk '{print $2}'");
    ?>
    <div class="flex items-center flex-wrap justify-between h-[72px] bg-gradient-to-r from-[#14243e] to-black-500 ">
        <div class="flex justify-center items-center w-[132px] h-[56px] ml-3 mt-1">
            <a href="index.html"> <img alt="CK" src="./assets/CK_Logo_HZ_white.png" /></a>
        </div>
      
        
        <div class="flex items-center mr-5 h-[72px] ">
            <a href="help.html">
           
                <h1 class="text-white text-md font-bold cursor-pointer font-inter leading-tight">Help &#63;</h1>
                    </a>
        </div>
    
    </div>
    <div class="middleDiv">
     
        

        <!-- CVE Heading and start button -->
    <div>
        
        
    

        <div class="image1 flex items-center justify-center mt-[10rem] ">
            <div class="h-[15rem] w-full mx-[50px]  flex-col flex items-center justify-center ">
                <div class="flex justify-center items-center w-full h-[40px] flex-col ">
                    <h1 class="text-white text-3xl font-[30px] cursor-pointer font-inter leading-tight rubik">{Replace_CVE_ID}</h1>
                  
                </div>
                <div class="w-full h-[40px]  mt-1">
                      <h3 class="text-white text-[30px] flex items-center justify-center font-bold" >{Replace_Vulnerability}</h3>
                </div>
                <!-- need to give the path of page you want to navigate -->
                <a href="http://<?php echo $ipAddress; ?>{Replace_Endpoint}">
                    <button type="button" class="h-10 w-[8rem] px-3 py-0.5 mt-9 bg-lime-500 rounded-[3px] cursor-pointer text-black text-md font-bold">
                        Start
                    </button>
                    
                </a>
            </div>
        </div>



        <!-- footer -->

        <div class="p-2 mt-[2.5%]  h-[199px] text-black text-md font-[10px] font-inter flex flex-col justify-center overflow-hidden">
            
                <p class="text-white px-[1rem] text-center h-full flex items-center justify-center">{Replace_Description}</p>
                <div class="flex justify-center items-center mt-3">
                    <p class="text-white text-sm leading-tight font-inter text-[8px] font-bold">Made by CyberKshetra 2024 &#169;</p>
                </div>
            
        </div>
        
        
    </div>
    </div>
   
    
</body>

</html>




