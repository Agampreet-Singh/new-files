/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/*.{html,js}"],
  theme: {
    extend: {
      colors: {
                        malachite: "#1ed760",
                        crayola: "#ff5948",
                        chineseBlack: "#121212",
                        raisinBlack: "#232323",
                        spanishGray: "#9e9e9e",
                        platinum: "#e4e4e4",
                        darkSilver: "#707070",
                        springBud: "#9fef04",
                        sheenGreen: "#87cc00",
                        royalGreen: "#10650f",
                        yankeesBlue: "#14243e",
                        spaceCadet: "#193258",
                        sunsetOrange: "#ff5656",
                        lightSlateGray: "#78869b",
                        cetaceanBlue: "#021648",
                        maastrichtBlue: "#09182F",
                    },
    },
  },
  plugins: [],
}

