<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>About Us - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<div class="page-head">
  <div class="container">
    <div class="breadcrumb"><a href="index.php">Home</a> / About Us</div>
    <h1>About Cosmos Bank</h1>
    <p>118 years of trust, transparency and transformative banking across India.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;">
      <div>
        <div class="section-title">Our Story</div>
        <div class="divider"></div>
        <p style="color:var(--gray);font-size:15px;line-height:1.8;margin-bottom:16px;">Founded in 1906 in Pune, Maharashtra, Cosmos Co-operative Bank Ltd has grown from a small community bank to one of India's largest urban cooperative banks with over 32 lakh members.</p>
        <p style="color:var(--gray);font-size:15px;line-height:1.8;margin-bottom:16px;">With a network of 140+ branches, 500+ ATMs and state-of-the-art digital banking infrastructure, we continue to serve the financial needs of individuals, businesses and NRIs.</p>
        <p style="color:var(--gray);font-size:15px;line-height:1.8;">Our commitment to cooperative banking principles ensures that every member benefits from the collective strength of our institution.</p>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div class="card" style="background:var(--teal-dark);color:#fff;border:none;">
          <div style="font-size:32px;font-weight:700;color:var(--gold);">1906</div>
          <div style="font-size:13px;color:#a0c8c8;margin-top:4px;">Year Founded</div>
        </div>
        <div class="card" style="background:var(--teal);color:#fff;border:none;">
          <div style="font-size:32px;font-weight:700;color:var(--gold);">140+</div>
          <div style="font-size:13px;color:#c0e0e0;margin-top:4px;">Branches</div>
        </div>
        <div class="card" style="background:var(--teal);color:#fff;border:none;">
          <div style="font-size:32px;font-weight:700;color:var(--gold);">32L+</div>
          <div style="font-size:13px;color:#c0e0e0;margin-top:4px;">Members</div>
        </div>
        <div class="card" style="background:var(--teal-dark);color:#fff;border:none;">
          <div style="font-size:32px;font-weight:700;color:var(--gold);">Rs.12K Cr</div>
          <div style="font-size:13px;color:#a0c8c8;margin-top:4px;">Total Business</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);">
  <div class="container">
    <div class="text-center">
      <div class="section-title">Mission &amp; Vision</div>
      <div class="divider divider-center"></div>
    </div>
    <div class="card-grid-2">
      <div class="card" style="border-left:4px solid var(--teal);">
        <div style="font-size:18px;font-weight:700;color:var(--teal);margin-bottom:12px;">Our Mission</div>
        <p style="color:var(--gray);line-height:1.8;">To provide accessible, affordable and innovative financial services to all segments of society while adhering to cooperative banking principles of mutual aid and democratic governance.</p>
      </div>
      <div class="card" style="border-left:4px solid var(--gold);">
        <div style="font-size:18px;font-weight:700;color:var(--gold);margin-bottom:12px;">Our Vision</div>
        <p style="color:var(--gray);line-height:1.8;">To become India's most trusted cooperative bank, recognized for financial inclusion, technological innovation and sustainable growth that benefits every member of our cooperative family.</p>
      </div>
    </div>
  </div>
</div>

<div class="section" id="leadership">
  <div class="container">
    <div class="section-title">Leadership Team</div>
    <div class="divider"></div>
    <div class="card-grid">
      <?php
      $leaders = [
        ['Milind Kale','Chairman & Managing Director','25+ years in cooperative banking. Former Director, NABARD.'],
        ['Sarita Deshmukh','Chief Executive Officer','IIM Ahmedabad alumna. Led digital transformation initiative.'],
        ['Rajesh Patil','Chief Financial Officer','CA, CFA. Expertise in treasury and risk management.'],
        ['Anupama Kulkarni','Chief Technology Officer','Former VP, Infosys BFS. Leads our digital banking platform.'],
        ['Devraj Iyer','Chief Risk Officer','20 years in banking risk, compliance and audit functions.'],
        ['Meera Bhatt','Head - Retail Banking','Grew retail deposits portfolio from Rs.1,200 Cr to Rs.4,800 Cr.'],
      ];
      foreach($leaders as $l):
      ?>
      <div class="card">
        <div style="width:56px;height:56px;background:var(--teal-light);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;color:var(--teal);margin-bottom:16px;"><?= strtoupper($l[0][0]) ?></div>
        <h3><?= $l[0] ?></h3>
        <div style="font-size:12.5px;color:var(--teal);font-weight:600;margin:4px 0 10px;"><?= $l[1] ?></div>
        <p><?= $l[2] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);" id="awards">
  <div class="container">
    <div class="section-title">Awards &amp; Recognition</div>
    <div class="divider"></div>
    <div class="card-grid">
      <div class="card">
        <div class="card-icon">&#127942;</div>
        <h3>Best Urban Cooperative Bank</h3>
        <p>Indian Banks Association (IBA) Award for Excellence in Urban Cooperative Banking — 2023, 2022, 2021.</p>
      </div>
      <div class="card">
        <div class="card-icon">&#128187;</div>
        <h3>Digital Innovation Award</h3>
        <p>NASSCOM Award for Best Digital Transformation in Cooperative Banking Sector — 2022.</p>
      </div>
      <div class="card">
        <div class="card-icon">&#127760;</div>
        <h3>Financial Inclusion Award</h3>
        <p>RBI Governor Award for Outstanding Contribution to Financial Inclusion in Maharashtra — 2021.</p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="js/main.js"></script>
</body>
</html>
