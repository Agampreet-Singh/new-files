<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<?php
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty(trim($_POST['name'] ?? ''))) $success = true;
}
?>
<div class="page-head">
  <div class="container">
    <div class="breadcrumb"><a href="index.php">Home</a> / Contact Us</div>
    <h1>Contact Us</h1>
    <p>Reach our head office team for administrative, technical or member support queries.</p>
  </div>
</div>
<div style="background:var(--teal-light);border-bottom:1px solid var(--border);padding:20px 0;">
  <div class="container">
    <div style="background:linear-gradient(120deg,var(--teal-dark),var(--teal));border-radius:10px;padding:22px 28px;color:#fff;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
      <div>
        <div style="font-size:12.5px;text-transform:uppercase;letter-spacing:1px;color:#cfe8e8;margin-bottom:4px;">Head Office Administration</div>
        <div style="font-size:24px;font-weight:700;"><a href="mailto:admin@cosmosbank.in" style="color:#fff;">admin@cosmosbank.in</a></div>
      </div>
      <div style="font-size:13px;color:#dff2f2;max-width:320px;">For account administration, technical escalations and official correspondence with Cosmos Bank's head office.</div>
    </div>
  </div>
</div>
<div class="section">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;">
      <div>
        <div class="section-title" style="font-size:22px;">Contact Details</div>
        <div class="divider"></div>
        <div style="display:flex;flex-direction:column;gap:20px;margin-bottom:28px;">
          <div class="card" style="padding:18px 22px;">
            <div style="font-size:13px;font-weight:700;color:var(--teal);margin-bottom:6px;">Head Office - Administration</div>
            <div style="font-size:14px;margin-bottom:4px;"><strong>admin@cosmosbank.in</strong></div>
            <div style="font-size:13.5px;color:var(--gray);">Phone: 1800-266-4433 (Toll Free)</div>
            <div style="font-size:13.5px;color:var(--gray);">Hours: Mon-Sat, 9:30 AM - 5:30 PM</div>
          </div>
          <div class="card" style="padding:18px 22px;">
            <div style="font-size:13px;font-weight:700;color:var(--teal);margin-bottom:6px;">Registered Office</div>
            <div style="font-size:13.5px;color:var(--gray);line-height:1.7;">269-A, Budhwar Peth,<br>Pune - 411002, Maharashtra<br>Tel: 020-2440-4433</div>
          </div>
          <div class="card" style="padding:18px 22px;">
            <div style="font-size:13px;font-weight:700;color:var(--teal);margin-bottom:6px;">Member Support</div>
            <div style="font-size:14px;margin-bottom:4px;"><strong>support@cosmosbank.in</strong></div>
            <div style="font-size:13.5px;color:var(--gray);">For account related queries, card issues and transaction disputes.</div>
          </div>
        </div>
      </div>
      <div>
        <div class="section-title" style="font-size:22px;">Send us a Message</div>
        <div class="divider"></div>
        <?php if ($success): ?>
        <div class="alert alert-success">Thank you <?= htmlspecialchars($_POST['name']) ?>! We have received your message and will respond within 2 working days.</div>
        <?php endif; ?>
        <div class="form-card">
          <form method="POST">
            <div class="form-grid">
              <div class="form-group">
                <label>Your Name *</label>
                <input type="text" name="name" placeholder="Full Name" required>
              </div>
              <div class="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" placeholder="your@email.com" required>
              </div>
              <div class="form-group">
                <label>Mobile Number</label>
                <input type="tel" name="phone" placeholder="98765 43210">
              </div>
              <div class="form-group">
                <label>Subject</label>
                <select name="subject">
                  <option>Account Query</option>
                  <option>Loan Enquiry</option>
                  <option>Net Banking Help</option>
                  <option>Card Issue</option>
                  <option>Complaint</option>
                  <option>Other</option>
                </select>
              </div>
              <div class="form-group full">
                <label>Message *</label>
                <textarea name="message" placeholder="Please describe your query in detail..." required></textarea>
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary">Send Message</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
<script src="js/main.js"></script>
</body>
</html>
