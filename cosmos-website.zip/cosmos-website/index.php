<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cosmos iBank - Multistate Scheduled Bank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<div class="ticker">
  <div class="container">
    <div class="ticker-inner">
      <span class="ticker-label">NOTICE</span>
      <span>Savings Account interest rate revised to 4.5% p.a. effective 1st October 2024 &nbsp; | &nbsp; New branch inaugurated at Nashik - Gangapur Road &nbsp; | &nbsp; Net Banking maintenance scheduled Sunday 2AM-4AM IST</span>
    </div>
  </div>
</div>

<div class="cat-strip">
  <div class="container">
    <a href="services.php" class="cat-link active">General</a>
    <a href="services.php#premium" class="cat-link">Premium Banking</a>
    <a href="services.php#nri" class="cat-link">NRI</a>
    <a href="services.php#business" class="cat-link">Business</a>
    <a href="services.php#digital" class="cat-link">Digital World</a>
  </div>
</div>

<div class="hero">
  <div class="container">
    <div class="hero-content">
      <div class="hero-badge">&#11088; Trusted since 1906 &mdash; 118 Years of Banking Excellence</div>
      <h1>Bank Smarter,<br>Grow <span>Stronger</span></h1>
      <p>Experience seamless banking with Cosmos iBank. Savings, loans, investments and digital services tailored for you, your family and your business.</p>
      <div class="hero-actions">
        <a href="netbanking.php" class="btn btn-gold btn-lg">Open Net Banking</a>
        <a href="loans.php" class="btn btn-outline btn-lg" style="border-color:rgba(255,255,255,0.5);color:#fff;">Apply for Loan</a>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><div class="num">32L+</div><div class="lbl">Account Holders</div></div>
        <div class="hero-stat"><div class="num">140+</div><div class="lbl">Branches Pan India</div></div>
        <div class="hero-stat"><div class="num">Rs.12,000 Cr</div><div class="lbl">Total Business</div></div>
        <div class="hero-stat"><div class="num">118 Yrs</div><div class="lbl">Of Trust</div></div>
      </div>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);">
  <div class="container">
    <div class="text-center">
      <div class="section-title">Our Products &amp; Services</div>
      <div class="section-sub" style="margin:0 auto;">Everything you need to manage your finances under one roof</div>
      <div class="divider divider-center"></div>
    </div>
    <div class="card-grid">
      <div class="card">
        <div class="card-icon">&#128176;</div>
        <h3>Savings Account</h3>
        <p>Earn up to 4.5% interest p.a. with zero minimum balance. Free debit card, internet banking and mobile app included.</p>
        <a href="services.php#accounts" class="card-link">Open Account &#8594;</a>
      </div>
      <div class="card">
        <div class="card-icon">&#127968;</div>
        <h3>Home Loans</h3>
        <p>Competitive interest rates starting at 8.40% p.a. with flexible repayment tenure up to 30 years.</p>
        <a href="loans.php" class="card-link">Apply Now &#8594;</a>
      </div>
      <div class="card">
        <div class="card-icon">&#128182;</div>
        <h3>Fixed Deposits</h3>
        <p>Safe and guaranteed returns up to 7.75% p.a. on deposits. Flexible tenure from 7 days to 10 years.</p>
        <a href="services.php#deposits" class="card-link">Invest Now &#8594;</a>
      </div>
      <div class="card">
        <div class="card-icon">&#128241;</div>
        <h3>Mobile Banking</h3>
        <p>Pay bills, transfer funds, check balance and more from anywhere. Available on iOS and Android.</p>
        <a href="services.php#digital" class="card-link">Know More &#8594;</a>
      </div>
      <div class="card">
        <div class="card-icon">&#9992;</div>
        <h3>NRI Services</h3>
        <p>NRE/NRO/FCNR accounts, remittance services and investment options designed for Non-Resident Indians.</p>
        <a href="services.php#nri" class="card-link">Explore &#8594;</a>
      </div>
      <div class="card">
        <div class="card-icon">&#128188;</div>
        <h3>Business Banking</h3>
        <p>Current accounts, trade finance, MSME loans and cash management solutions for your business needs.</p>
        <a href="services.php#business" class="card-link">Get Started &#8594;</a>
      </div>
    </div>
  </div>
</div>

<div class="section">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;">
      <div>
        <div class="section-title">Quick Loan in 48 Hours</div>
        <div class="divider"></div>
        <p style="color:var(--gray);font-size:15px;line-height:1.8;margin-bottom:24px;">Get instant approval on personal loans, home loans and business loans. Minimal documentation, quick disbursal directly to your account.</p>
        <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:28px;">
          <div style="display:flex;align-items:center;gap:12px;font-size:14px;">
            <span style="color:var(--teal);font-weight:700;">&#10003;</span> Personal Loans up to Rs. 25 Lakh
          </div>
          <div style="display:flex;align-items:center;gap:12px;font-size:14px;">
            <span style="color:var(--teal);font-weight:700;">&#10003;</span> Instant approval in 48 hours
          </div>
          <div style="display:flex;align-items:center;gap:12px;font-size:14px;">
            <span style="color:var(--teal);font-weight:700;">&#10003;</span> Interest rates from 10.5% p.a.
          </div>
          <div style="display:flex;align-items:center;gap:12px;font-size:14px;">
            <span style="color:var(--teal);font-weight:700;">&#10003;</span> Flexible repayment 12-60 months
          </div>
        </div>
        <a href="loans.php" class="btn btn-primary btn-lg">Apply for Loan</a>
      </div>
      <div class="info-strip" style="flex-direction:column;align-items:flex-start;gap:16px;">
        <div class="section-title" style="font-size:22px;">Current Interest Rates</div>
        <table class="rate-table" style="width:100%;">
          <tr><th>Product</th><th>Rate (p.a.)</th></tr>
          <tr><td>Savings Account</td><td class="rate-highlight">4.50%</td></tr>
          <tr><td>Fixed Deposit (1 Yr)</td><td class="rate-highlight">7.25%</td></tr>
          <tr><td>Home Loan</td><td class="rate-highlight">8.40%</td></tr>
          <tr><td>Personal Loan</td><td class="rate-highlight">10.50%</td></tr>
          <tr><td>Gold Loan</td><td class="rate-highlight">9.00%</td></tr>
        </table>
        <a href="resources.php#rates" class="btn btn-outline btn-sm">View All Rates</a>
      </div>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);">
  <div class="container">
    <div class="text-center">
      <div class="section-title">Why Choose Cosmos Bank?</div>
      <div class="divider divider-center"></div>
    </div>
    <div class="card-grid-4">
      <div class="card text-center">
        <div class="card-icon" style="margin:0 auto 16px;">&#128274;</div>
        <h3>Bank-Grade Security</h3>
        <p>256-bit SSL encryption and multi-factor authentication for all transactions.</p>
      </div>
      <div class="card text-center">
        <div class="card-icon" style="margin:0 auto 16px;">&#128336;</div>
        <h3>24x7 Banking</h3>
        <p>Round-the-clock access via our mobile app, net banking and ATM network.</p>
      </div>
      <div class="card text-center">
        <div class="card-icon" style="margin:0 auto 16px;">&#127881;</div>
        <h3>Award Winning</h3>
        <p>Best Cooperative Bank award by IBA for 3 consecutive years (2021-2023).</p>
      </div>
      <div class="card text-center">
        <div class="card-icon" style="margin:0 auto 16px;">&#128101;</div>
        <h3>32 Lakh+ Members</h3>
        <p>Trusted by millions of families, businesses and NRIs across the country.</p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="js/main.js"></script>
</body>
</html>
