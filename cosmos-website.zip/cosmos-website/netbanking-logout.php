<?php
session_start();
session_destroy();
header('Location: netbanking.php');
exit;
