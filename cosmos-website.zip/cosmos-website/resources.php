<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Resources - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="page-head">
  <div class="container">
    <div class="breadcrumb"><a href="index.php">Home</a> / Resources</div>
    <h1>Resources &amp; Support</h1>
    <p>Forms, interest rates, FAQs and everything you need to bank with us.</p>
  </div>
</div>

<div class="section" id="rates">
  <div class="container">
    <div class="section-title">Interest Rates</div>
    <div class="divider"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;">
      <div>
        <h3 style="margin-bottom:16px;font-size:16px;color:var(--teal);">Deposit Rates</h3>
        <table class="rate-table">
          <tr><th>Product</th><th>Rate (p.a.)</th><th>Senior Citizen</th></tr>
          <tr><td>Savings Account</td><td class="rate-highlight">4.50%</td><td class="rate-highlight">5.00%</td></tr>
          <tr><td>FD - 1 Year</td><td class="rate-highlight">7.25%</td><td class="rate-highlight">7.75%</td></tr>
          <tr><td>FD - 2 Years</td><td class="rate-highlight">7.00%</td><td class="rate-highlight">7.50%</td></tr>
          <tr><td>FD - 3 Years</td><td class="rate-highlight">6.75%</td><td class="rate-highlight">7.25%</td></tr>
          <tr><td>Recurring Deposit</td><td class="rate-highlight">7.00%</td><td class="rate-highlight">7.50%</td></tr>
        </table>
      </div>
      <div>
        <h3 style="margin-bottom:16px;font-size:16px;color:var(--teal);">Lending Rates</h3>
        <table class="rate-table">
          <tr><th>Product</th><th>Rate (p.a.)</th><th>Max Tenure</th></tr>
          <tr><td>Home Loan</td><td class="rate-highlight">8.40%</td><td>30 Years</td></tr>
          <tr><td>Personal Loan</td><td class="rate-highlight">10.50%</td><td>5 Years</td></tr>
          <tr><td>Business Loan</td><td class="rate-highlight">11.00%</td><td>7 Years</td></tr>
          <tr><td>Gold Loan</td><td class="rate-highlight">9.00%</td><td>3 Years</td></tr>
          <tr><td>Vehicle Loan</td><td class="rate-highlight">9.50%</td><td>7 Years</td></tr>
        </table>
      </div>
    </div>
    <p style="font-size:12px;color:var(--gray);margin-top:16px;">* Rates are indicative and subject to change. Final rate depends on credit profile. Last updated: October 2024.</p>
  </div>
</div>

<div class="section" style="background:var(--light);" id="forms">
  <div class="container">
    <div class="section-title">Download Forms</div>
    <div class="divider"></div>
    <div class="card-grid">
      <?php
      $forms=[['Account Opening Form','For new savings/current account opening','PDF, 280 KB'],['KYC Update Form','Update your KYC documents','PDF, 180 KB'],['Nomination Form','Add/change nominee for your accounts','PDF, 120 KB'],['Loan Application Form','General purpose loan application','PDF, 340 KB'],['FD/RD Application','Open Fixed or Recurring Deposit','PDF, 210 KB'],['NEFT/RTGS Mandate','For fund transfer authorization','PDF, 160 KB']];
      foreach($forms as $f): ?>
      <div class="card" style="display:flex;flex-direction:column;">
        <div class="card-icon">&#128196;</div>
        <h3><?= $f[0] ?></h3>
        <p><?= $f[1] ?></p>
        <div style="margin-top:auto;padding-top:16px;display:flex;align-items:center;justify-content:space-between;">
          <span style="font-size:12px;color:var(--gray);"><?= $f[2] ?></span>
          <a href="#" onclick="alert('Form download initiated. This is a demo environment.')" class="btn btn-outline btn-sm">Download</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="section" id="faq">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:48px;">
      <div>
        <div class="section-title">Frequently Asked Questions</div>
        <div class="divider"></div>
        <p style="color:var(--gray);line-height:1.8;">Find answers to common queries about our banking products and services. Can't find what you're looking for? <a href="contact.php" style="color:var(--teal);">Contact us</a>.</p>
      </div>
      <div>
        <?php
        $faqs=[
          ['How do I open a savings account online?','Visit netbanking.php, click Register, fill personal details and complete KYC via Aadhaar OTP. Your account will be active within 24 hours.'],
          ['What is the minimum balance for savings account?','Cosmos Bank offers zero minimum balance savings accounts. No penalty for low balance.'],
          ['How can I reset my Net Banking password?','Click Forgot Password on the Net Banking login page, enter your registered mobile number, and follow the OTP verification process.'],
          ['Is my deposit insured?','Yes. Deposits are insured up to Rs. 5 Lakh per depositor under the DICGC scheme (RBI regulated).'],
          ['How do I apply for a loan?','You can apply online through our Loans page, visit any branch, or call 1800-266-4433. Our team will guide you through the process.'],
          ['Can I open an NRI account online?','NRI account opening requires branch visit or through our representative offices. Contact admin@cosmosbank.in for assistance.'],
        ];
        foreach($faqs as $i=>$faq): ?>
        <div class="faq-item">
          <div class="faq-q" onclick="toggleFaq(<?= $i ?>)">
            <?= $faq[0] ?>
            <span class="faq-icon" id="icon<?= $i ?>">+</span>
          </div>
          <div class="faq-a" id="faq<?= $i ?>"><?= $faq[1] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function toggleFaq(i){
  var a=document.getElementById('faq'+i), ic=document.getElementById('icon'+i);
  a.classList.toggle('open'); ic.classList.toggle('open');
  ic.textContent=ic.classList.contains('open')? '-' : '+';
}
</script>
<script src="js/main.js"></script>
</body>
</html>
