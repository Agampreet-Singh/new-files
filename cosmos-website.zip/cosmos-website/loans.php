<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Loans - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>

<?php
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    if (!empty($name)) $success = true;
}
?>

<div class="page-head">
  <div class="container">
    <div class="breadcrumb"><a href="index.php">Home</a> / Loans</div>
    <h1>Loan Products</h1>
    <p>Quick approvals, competitive rates, flexible repayment. Apply online in minutes.</p>
  </div>
</div>

<div class="section" style="background:var(--light);">
  <div class="container">
    <div class="card-grid">
      <div class="card"><div class="card-icon">&#127968;</div><h3>Home Loan</h3><p>Finance your dream home with loans from Rs. 5 Lakh to Rs. 5 Crore. Rates from 8.40% p.a., tenure up to 30 years.</p><a href="#apply" onclick="setType('Home Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
      <div class="card"><div class="card-icon">&#128188;</div><h3>Personal Loan</h3><p>Instant personal loans up to Rs. 25 Lakh for any purpose. Rates from 10.50% p.a., no collateral required.</p><a href="#apply" onclick="setType('Personal Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
      <div class="card"><div class="card-icon">&#127970;</div><h3>Business Loan</h3><p>Working capital and term loans for MSMEs up to Rs. 2 Crore. Collateral-free under CGTMSE scheme.</p><a href="#apply" onclick="setType('Business Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
      <div class="card"><div class="card-icon">&#128218;</div><h3>Education Loan</h3><p>Fund your higher education in India or abroad up to Rs. 40 Lakh. Repayment starts after course completion.</p><a href="#apply" onclick="setType('Education Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
      <div class="card"><div class="card-icon">&#128663;</div><h3>Vehicle Loan</h3><p>Finance new and used vehicles at rates starting 9.00% p.a. Up to 90% on-road funding, tenure up to 7 years.</p><a href="#apply" onclick="setType('Vehicle Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
      <div class="card"><div class="card-icon">&#128142;</div><h3>Gold Loan</h3><p>Instant loan against gold jewellery at 9.00% p.a. Get up to 75% of gold value. Minimal documentation.</p><a href="#apply" onclick="setType('Gold Loan')" class="btn btn-primary btn-sm" style="margin-top:14px;">Apply Now</a></div>
    </div>
  </div>
</div>

<div class="section" id="apply">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start;">
      <div>
        <div class="section-title">Apply for a Loan</div>
        <div class="divider"></div>
        <?php if ($success): ?>
        <div class="alert alert-success">
          <strong>Application Received!</strong> Thank you <?= htmlspecialchars($_POST['name']) ?>. Our loan officer will contact you on <?= htmlspecialchars($_POST['phone']) ?> within 24 hours. Your reference number is <strong>LN<?= rand(100000,999999) ?></strong>.
        </div>
        <?php endif; ?>
        <div class="form-card">
          <form method="POST" action="#apply">
            <div class="form-title">Quick Loan Application</div>
            <div class="form-sub">Fill the form and our team will call you back within 24 hours</div>
            <div class="form-grid">
              <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="name" placeholder="Ramesh Kulkarni" required>
              </div>
              <div class="form-group">
                <label>Mobile Number *</label>
                <input type="tel" name="phone" placeholder="98765 43210" required>
              </div>
              <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="ramesh@example.com">
              </div>
              <div class="form-group">
                <label>Loan Type *</label>
                <select name="loan_type" id="loan_type" required>
                  <option value="">Select Loan Type</option>
                  <option>Home Loan</option>
                  <option>Personal Loan</option>
                  <option>Business Loan</option>
                  <option>Education Loan</option>
                  <option>Vehicle Loan</option>
                  <option>Gold Loan</option>
                </select>
              </div>
              <div class="form-group">
                <label>Loan Amount Required</label>
                <select name="amount">
                  <option>Up to Rs. 5 Lakh</option>
                  <option>Rs. 5-10 Lakh</option>
                  <option>Rs. 10-25 Lakh</option>
                  <option>Rs. 25-50 Lakh</option>
                  <option>Rs. 50 Lakh - 1 Crore</option>
                  <option>Above Rs. 1 Crore</option>
                </select>
              </div>
              <div class="form-group">
                <label>Employment Type</label>
                <select name="employment">
                  <option>Salaried</option>
                  <option>Self Employed</option>
                  <option>Business Owner</option>
                  <option>Professional</option>
                </select>
              </div>
              <div class="form-group">
                <label>City</label>
                <input type="text" name="city" placeholder="Pune">
              </div>
              <div class="form-group">
                <label>Annual Income</label>
                <select name="income">
                  <option>Below Rs. 3 Lakh</option>
                  <option>Rs. 3-6 Lakh</option>
                  <option>Rs. 6-12 Lakh</option>
                  <option>Rs. 12-25 Lakh</option>
                  <option>Above Rs. 25 Lakh</option>
                </select>
              </div>
              <div class="form-group full">
                <label>Any specific requirement or message</label>
                <textarea name="message" placeholder="Please share any specific requirement or query..."></textarea>
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-lg">Submit Application</button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div>
        <div class="section-title" style="font-size:22px;">EMI Calculator</div>
        <div class="divider"></div>
        <div class="card" style="margin-bottom:20px;">
          <h3 style="margin-bottom:16px;">Calculate Your EMI</h3>
          <div class="form-group" style="margin-bottom:14px;">
            <label>Loan Amount (Rs.)</label>
            <input type="number" id="lamt" value="1000000" oninput="calcEMI()">
          </div>
          <div class="form-group" style="margin-bottom:14px;">
            <label>Interest Rate (% p.a.)</label>
            <input type="number" id="lrate" value="10.5" step="0.1" oninput="calcEMI()">
          </div>
          <div class="form-group" style="margin-bottom:14px;">
            <label>Tenure (Months)</label>
            <input type="number" id="ltenure" value="60" oninput="calcEMI()">
          </div>
        </div>
        <div class="calc-wrap">
          <h3>Your EMI Breakdown</h3>
          <div class="calc-row"><span>Monthly EMI</span><span id="remi">Rs. 0</span></div>
          <div class="calc-row"><span>Total Interest</span><span id="rint">Rs. 0</span></div>
          <div class="calc-row"><span>Principal Amount</span><span id="rprin">Rs. 0</span></div>
          <div class="calc-row calc-total"><span>Total Payable</span><span id="rtotal">Rs. 0</span></div>
        </div>

        <div class="info-strip" style="margin-top:24px;">
          <div>
            <div class="info-strip-title">Need help choosing?</div>
            <div class="info-strip-sub">Talk to our loan specialist for free guidance on the best loan product for your needs.</div>
          </div>
          <a href="contact.php" class="btn btn-primary">Contact Us</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function setType(t){ document.getElementById('loan_type').value=t; document.getElementById('apply').scrollIntoView({behavior:'smooth'}); }
function fmt(n){ return 'Rs. '+Math.round(n).toLocaleString('en-IN'); }
function calcEMI(){
  let P=parseFloat(document.getElementById('lamt').value)||0;
  let r=parseFloat(document.getElementById('lrate').value)/12/100;
  let n=parseInt(document.getElementById('ltenure').value)||1;
  let emi = r ? P*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1) : P/n;
  let total=emi*n, interest=total-P;
  document.getElementById('remi').textContent=fmt(emi);
  document.getElementById('rint').textContent=fmt(interest);
  document.getElementById('rprin').textContent=fmt(P);
  document.getElementById('rtotal').textContent=fmt(total);
}
calcEMI();
</script>
<script src="js/main.js"></script>
</body>
</html>
