<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Net Banking Login - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
session_start();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    if (empty($user) || empty($pass)) {
        $error = 'Please enter username and password.';
    } else {
        $_SESSION['nb_user'] = $user;
        $_SESSION['nb_name'] = explode('@',$user)[0];
        header('Location: netbanking-dashboard.php');
        exit;
    }
}
?>
<div class="nb-page">
  <div class="nb-left">
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:40px;">
      <svg width="44" height="44" viewBox="0 0 44 44"><circle cx="22" cy="22" r="20" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"/><circle cx="22" cy="22" r="8" fill="rgba(255,255,255,0.2)"/></svg>
      <div><div style="font-size:20px;font-weight:700;color:#fff;">Cosmos iBank</div><div style="font-size:11px;color:#a0c8c8;">MULTISTATE SCHEDULED BANK</div></div>
    </div>
    <h1>Welcome to<br>Cosmos Net Banking</h1>
    <p>Manage your accounts, pay bills, transfer funds and invest — all from the comfort of your home. Secure. Simple. Smart.</p>
    <div class="nb-features">
      <div class="nb-feature"><div class="nb-feature-icon">&#128274;</div><div class="nb-feature-text">256-bit SSL encrypted connection</div></div>
      <div class="nb-feature"><div class="nb-feature-icon">&#128241;</div><div class="nb-feature-text">OTP-based two-factor authentication</div></div>
      <div class="nb-feature"><div class="nb-feature-icon">&#128336;</div><div class="nb-feature-text">24x7 banking at your fingertips</div></div>
      <div class="nb-feature"><div class="nb-feature-icon">&#127881;</div><div class="nb-feature-text">Zero transaction fees on NEFT/IMPS</div></div>
    </div>
  </div>
  <div class="nb-right">
    <div class="nb-form-wrap">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:28px;">
        <svg width="36" height="36" viewBox="0 0 44 44"><circle cx="22" cy="22" r="20" fill="none" stroke="#0a4d4d" stroke-width="2.5"/><circle cx="22" cy="22" r="8" fill="#0f6e6e"/></svg>
        <div><div style="font-size:16px;font-weight:700;color:var(--teal-dark);">Cosmos iBank</div></div>
      </div>
      <div style="font-size:22px;font-weight:700;color:var(--ink);margin-bottom:4px;">Sign in to Net Banking</div>
      <div style="font-size:13px;color:var(--gray);margin-bottom:24px;">Please enter your Customer ID and password</div>
      <div class="nb-tabs">
        <button class="nb-tab active">Net Banking</button>
        <button class="nb-tab" onclick="alert('Corporate banking login available at branch. Contact admin@cosmosbank.in')">Corporate</button>
      </div>
      <?php if ($error): ?>
      <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <form method="POST">
        <div class="form-group" style="margin-bottom:16px;">
          <label>Customer ID / User ID</label>
          <input type="text" name="username" placeholder="Enter your Customer ID or email" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group" style="margin-bottom:8px;">
          <label>Login Password</label>
          <input type="password" name="password" placeholder="Enter your password" required>
        </div>
        <div style="text-align:right;margin-bottom:20px;">
          <a href="#" onclick="alert('OTP will be sent to your registered mobile. Contact 1800-266-4433 if unregistered.')" style="font-size:13px;color:var(--teal);">Forgot Password?</a>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">Login Securely</button>
      </form>
      <div style="text-align:center;margin-top:20px;font-size:13px;color:var(--gray);">
        New customer? <a href="#" onclick="alert('Visit your nearest Cosmos Bank branch to get your Net Banking credentials.')" style="color:var(--teal);font-weight:600;">Register for Net Banking</a>
      </div>
      <div style="margin-top:28px;padding-top:20px;border-top:1px solid var(--border);display:flex;align-items:center;gap:8px;">
        <span style="font-size:11px;color:var(--gray);">&#128274; Secured by</span>
        <span style="font-size:11px;background:var(--teal-light);color:var(--teal);padding:2px 8px;border-radius:4px;font-weight:600;">256-bit SSL</span>
        <span style="font-size:11px;color:var(--gray);">|</span>
        <a href="contact.php" style="font-size:11px;color:var(--gray);">Need Help?</a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
