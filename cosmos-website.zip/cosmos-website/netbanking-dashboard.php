<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Account - Cosmos iBank Net Banking</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
session_start();
if (!isset($_SESSION['nb_user'])) { header('Location: netbanking.php'); exit; }
$user = $_SESSION['nb_user'];
$name = ucfirst($_SESSION['nb_name'] ?? 'Customer');
?>
<div class="db-header">
  <div class="container">
    <div class="db-nav">
      <div style="display:flex;align-items:center;gap:14px;">
        <svg width="32" height="32" viewBox="0 0 44 44"><circle cx="22" cy="22" r="20" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2"/><circle cx="22" cy="22" r="8" fill="rgba(255,255,255,0.2)"/></svg>
        <div style="font-size:16px;font-weight:700;color:#fff;">Cosmos iBank</div>
        <span style="color:#a0c8c8;font-size:13px;">| Net Banking</span>
      </div>
      <div style="display:flex;align-items:center;gap:20px;">
        <span style="font-size:13px;color:#a0c8c8;">Welcome, <strong style="color:#fff;"><?= htmlspecialchars($name) ?></strong></span>
        <span style="font-size:12px;color:#7a9a9a;">Last Login: <?= date('d M Y, h:i A', strtotime('-2 hours')) ?></span>
        <a href="netbanking-logout.php" class="btn btn-sm" style="background:rgba(255,255,255,0.12);color:#fff;">Logout</a>
      </div>
    </div>
  </div>
</div>

<div style="background:#f5f7fa;border-bottom:1px solid var(--border);">
  <div class="container">
    <div style="display:flex;gap:2px;">
      <?php foreach(['Accounts','Fund Transfer','Bill Pay','FD/RD','Loans','Profile'] as $m): ?>
      <a href="#" onclick="return false;" style="padding:12px 18px;font-size:13.5px;font-weight:500;color:var(--gray);display:block;transition:all 0.2s;" onmouseover="this.style.color='var(--teal)'" onmouseout="this.style.color='var(--gray)'"><?= $m ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div style="background:var(--light);padding:32px 0;min-height:calc(100vh - 120px);">
  <div class="container">
    <div class="db-grid">
      <div class="db-card">
        <div class="db-label">Savings Account</div>
        <div class="db-val">Rs. 84,230.50</div>
        <div class="db-sub">A/C No: XXXX XXXX 7834</div>
      </div>
      <div class="db-card">
        <div class="db-label">FD Maturity Value</div>
        <div class="db-val">Rs. 1,08,750.00</div>
        <div class="db-sub">Matures: 15 Jan 2025</div>
      </div>
      <div class="db-card">
        <div class="db-label">Loan Outstanding</div>
        <div class="db-val">Rs. 2,34,100.00</div>
        <div class="db-sub">Next EMI: 5 Nov 2024</div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:24px;">
      <div style="background:#fff;border-radius:14px;padding:24px;border:1px solid var(--border);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
          <h3 style="font-size:15px;font-weight:700;">Recent Transactions</h3>
          <a href="#" onclick="alert('Full statement will be sent to your registered email.')" style="font-size:13px;color:var(--teal);">View All Statements</a>
        </div>
        <?php
        $txns=[
          ['UPI Payment - Swiggy','12 Oct 2024','debit','-Rs. 340.00'],
          ['Salary Credit - Techsoft','10 Oct 2024','credit','+Rs. 52,000.00'],
          ['EMI - Home Loan','5 Oct 2024','debit','-Rs. 18,200.00'],
          ['ATM Withdrawal - Pune Branch','3 Oct 2024','debit','-Rs. 5,000.00'],
          ['NEFT - Ramesh Kumar','1 Oct 2024','credit','+Rs. 10,000.00'],
          ['Electricity Bill - MSEDCL','28 Sep 2024','debit','-Rs. 2,340.00'],
        ];
        foreach($txns as $t): ?>
        <div class="txn-row">
          <div class="txn-icon <?= $t[2]==='credit'?'txn-credit':'txn-debit' ?>"><?= $t[2]==='credit'?'&#8595;':'&#8593;' ?></div>
          <div class="txn-info">
            <div class="txn-name"><?= $t[0] ?></div>
            <div class="txn-date"><?= $t[1] ?></div>
          </div>
          <div class="txn-amt <?= $t[2] ?>"><?= $t[3] ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <div style="display:flex;flex-direction:column;gap:16px;">
        <div style="background:#fff;border-radius:14px;padding:22px;border:1px solid var(--border);">
          <h3 style="font-size:15px;font-weight:700;margin-bottom:16px;">Quick Actions</h3>
          <?php
          $actions=[['&#128178;','Fund Transfer','Transfer to any bank account'],['&#128203;','Pay Bills','Electricity, water, mobile recharge'],['&#128181;','Fixed Deposit','Open FD/RD online'],['&#128200;','Account Statement','Download PDF statement']];
          foreach($actions as $a): ?>
          <div onclick="alert('<?= $a[2] ?> — feature available. Please visit branch or call 1800-266-4433.')" style="display:flex;align-items:center;gap:12px;padding:12px;border-radius:8px;cursor:pointer;transition:all 0.2s;" onmouseover="this.style.background='var(--teal-light)'" onmouseout="this.style.background='transparent'">
            <span style="font-size:20px;width:36px;text-align:center;"><?= $a[0] ?></span>
            <div><div style="font-size:13.5px;font-weight:600;"><?= $a[1] ?></div><div style="font-size:12px;color:var(--gray);"><?= $a[2] ?></div></div>
          </div>
          <?php endforeach; ?>
        </div>

        <div style="background:var(--teal-dark);border-radius:14px;padding:22px;color:#fff;">
          <div style="font-size:13px;color:#a0c8c8;margin-bottom:4px;">Pre-approved Offer</div>
          <div style="font-size:18px;font-weight:700;margin-bottom:8px;">Personal Loan<br><span style="color:var(--gold);">Rs. 5,00,000</span></div>
          <div style="font-size:12.5px;color:#c0e0e0;margin-bottom:16px;">At 10.5% p.a. — Click to apply in 2 minutes</div>
          <a href="loans.php" class="btn btn-sm" style="background:var(--gold);color:#fff;">Apply Now</a>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
