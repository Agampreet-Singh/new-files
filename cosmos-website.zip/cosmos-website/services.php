<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Services - Cosmos iBank</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/nav.php'; ?>
<div class="page-head">
  <div class="container">
    <div class="breadcrumb"><a href="index.php">Home</a> / Services</div>
    <h1>Our Banking Services</h1>
    <p>A complete suite of financial products designed for every stage of your life.</p>
  </div>
</div>
<div class="section" id="accounts">
  <div class="container">
    <div class="section-title">Deposit Accounts</div>
    <div class="divider"></div>
    <div class="scheme-tabs">
      <div class="scheme-tab active" onclick="switchTab(this,'savings')">Savings Account</div>
      <div class="scheme-tab" onclick="switchTab(this,'current')">Current Account</div>
      <div class="scheme-tab" onclick="switchTab(this,'salary')">Salary Account</div>
    </div>
    <div id="savings" class="scheme-panel active">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;align-items:start;">
        <div>
          <h3 style="font-size:20px;margin-bottom:12px;">Cosmos Savings Account</h3>
          <p style="color:var(--gray);line-height:1.8;margin-bottom:16px;">Our flagship savings account offers the best interest rates with zero minimum balance requirement. Designed for salaried individuals, students and homemakers.</p>
          <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px;">
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;"><span style="color:var(--gray);">Interest Rate</span><strong>4.50% p.a.</strong></div>
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;"><span style="color:var(--gray);">Minimum Balance</span><strong>Zero</strong></div>
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;"><span style="color:var(--gray);">Free ATM Withdrawals</span><strong>5 per month</strong></div>
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;"><span style="color:var(--gray);">Internet Banking</span><strong>Free</strong></div>
            <div style="display:flex;justify-content:space-between;padding:10px 0;font-size:14px;"><span style="color:var(--gray);">Debit Card</span><strong>RuPay / Visa</strong></div>
          </div>
          <a href="netbanking.php" class="btn btn-primary">Open Account Online</a>
        </div>
        <div class="card" style="background:var(--teal-light);border:none;">
          <h3 style="margin-bottom:16px;">Features &amp; Benefits</h3>
          <?php foreach(['Free passbook & e-statements','SMS &amp; email alerts on every transaction','Sweep-in FD facility for idle funds','Nomination facility','Insurance cover up to Rs. 5 Lakh (DICGC)','Priority customer service'] as $f): ?>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:13.5px;"><span style="color:var(--teal);font-weight:700;">&#10003;</span><?= $f ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div id="current" class="scheme-panel">
      <div class="card"><h3>Current Account</h3><p style="color:var(--gray);margin-top:8px;">For businesses, traders and professionals who need unlimited transactions. Available in Classic (Rs.10,000 AQB), Premium (Rs.50,000 AQB) and Elite (Rs.1 Lakh AQB) variants. Includes overdraft facility, free NEFT/RTGS and dedicated relationship manager.</p><div style="margin-top:16px;"><a href="contact.php" class="btn btn-primary">Talk to Relationship Manager</a></div></div>
    </div>
    <div id="salary" class="scheme-panel">
      <div class="card"><h3>Salary Account</h3><p style="color:var(--gray);margin-top:8px;">Zero balance salary account for corporate employees. Includes free personal accident insurance of Rs. 2 Lakh, air accident insurance of Rs. 25 Lakh, unlimited ATM withdrawals across all bank ATMs, and pre-approved personal loan eligibility after 3 months of salary credits.</p><div style="margin-top:16px;"><a href="contact.php" class="btn btn-primary">Tie-up for Your Organization</a></div></div>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);" id="deposits">
  <div class="container">
    <div class="section-title">Fixed &amp; Recurring Deposits</div>
    <div class="divider"></div>
    <table class="rate-table" style="margin-bottom:24px;">
      <tr><th>Tenure</th><th>General Public</th><th>Senior Citizens</th></tr>
      <?php
      $rates=[['7 - 14 days','3.50%','4.00%'],['15 - 29 days','3.75%','4.25%'],['30 - 45 days','4.00%','4.50%'],['46 - 90 days','4.75%','5.25%'],['91 - 180 days','5.50%','6.00%'],['181 - 365 days','6.50%','7.00%'],['1 - 2 years','7.25%','7.75%'],['2 - 3 years','7.00%','7.50%'],['3 - 5 years','6.75%','7.25%'],['5 - 10 years','6.50%','7.00%']];
      foreach($rates as $r): ?>
      <tr><td><?= $r[0] ?></td><td class="rate-highlight"><?= $r[1] ?></td><td class="rate-highlight"><?= $r[2] ?></td></tr>
      <?php endforeach; ?>
    </table>
    <a href="loans.php" class="btn btn-primary">Open FD Online</a>
  </div>
</div>

<div class="section" id="digital">
  <div class="container">
    <div class="section-title">Digital Banking</div>
    <div class="divider"></div>
    <div class="card-grid">
      <div class="card"><div class="card-icon">&#128187;</div><h3>Net Banking</h3><p>Full-featured internet banking with fund transfer, bill payment, FD booking, loan EMI payment and account statements.</p><a href="netbanking.php" class="card-link">Login Now &#8594;</a></div>
      <div class="card"><div class="card-icon">&#128241;</div><h3>Mobile App</h3><p>Cosmos Mobile Banking app for iOS and Android. UPI, IMPS, NEFT, bill payments and account management on the go.</p><a href="#" class="card-link">Download App &#8594;</a></div>
      <div class="card"><div class="card-icon">&#128179;</div><h3>Debit Cards</h3><p>RuPay Platinum and Visa Debit cards with contactless payment, e-commerce transactions and global acceptance.</p><a href="contact.php" class="card-link">Apply Now &#8594;</a></div>
    </div>
  </div>
</div>

<div class="section" style="background:var(--light);" id="nri">
  <div class="container">
    <div class="section-title">NRI Services</div>
    <div class="divider"></div>
    <div class="card-grid">
      <div class="card"><div class="card-icon">&#127760;</div><h3>NRE Account</h3><p>Non-Resident External account for parking foreign earnings in India. Tax-free interest, freely repatriable principal and interest. Rate: 7.25% p.a.</p></div>
      <div class="card"><div class="card-icon">&#128178;</div><h3>NRO Account</h3><p>Manage income earned in India (rent, pension, dividends). Repatriate up to USD 1 million per financial year subject to tax.</p></div>
      <div class="card"><div class="card-icon">&#128188;</div><h3>FCNR Deposits</h3><p>Foreign Currency Non-Resident deposits in USD, GBP, EUR, JPY and AUD. Fully repatriable, tax exempt in India.</p></div>
    </div>
  </div>
</div>

<div class="section" id="business">
  <div class="container">
    <div class="section-title">Business Banking</div>
    <div class="divider"></div>
    <div class="card-grid">
      <div class="card"><div class="card-icon">&#127970;</div><h3>MSME Loans</h3><p>Working capital, term loans and equipment finance for Micro, Small and Medium Enterprises. Collateral-free loans up to Rs. 10 Lakh under CGTMSE.</p><a href="loans.php" class="card-link">Apply &#8594;</a></div>
      <div class="card"><div class="card-icon">&#128200;</div><h3>Trade Finance</h3><p>Letter of Credit, Bank Guarantee, Export/Import financing and forex services for businesses engaged in international trade.</p><a href="contact.php" class="card-link">Know More &#8594;</a></div>
      <div class="card"><div class="card-icon">&#128184;</div><h3>Cash Management</h3><p>Centralized collection, payments and liquidity management solutions for mid-size and large enterprises.</p><a href="contact.php" class="card-link">Get Quote &#8594;</a></div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function switchTab(el,id){
  document.querySelectorAll('.scheme-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.scheme-panel').forEach(p=>p.classList.remove('active'));
  el.classList.add('active');
  document.getElementById(id).classList.add('active');
}
</script>
<script src="js/main.js"></script>
</body>
</html>
