<?php $page = basename($_SERVER['PHP_SELF'], '.php'); ?>
<div class="topbar">
  <div class="container">
    <a href="contact.php">Contact Us</a>
    <a href="#">Locate Branch/ATM</a>
    <a href="#">EN | HI</a>
  </div>
</div>
<header>
  <div class="container">
    <div class="header-inner">
      <a href="index.php" class="brand">
        <svg width="44" height="44" viewBox="0 0 44 44">
          <circle cx="22" cy="22" r="20" fill="none" stroke="#0a4d4d" stroke-width="2.5"/>
          <path d="M22 5 A17 17 0 0 1 39 22" fill="none" stroke="#c9974a" stroke-width="3.5" stroke-linecap="round"/>
          <circle cx="22" cy="22" r="8" fill="#0f6e6e"/>
          <path d="M18 22 L21 25 L27 18" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <div>
          <div class="brand-name">Cosmos iBank</div>
          <div class="brand-tag">Multistate Scheduled Bank</div>
        </div>
      </a>
      <nav>
        <div class="nav-item">
          <a class="nav-link <?= $page==='index'?'active':'' ?>" href="index.php">Home</a>
        </div>
        <div class="nav-item">
          <div class="nav-link <?= $page==='about'?'active':'' ?>">About Us <span style="font-size:10px;">&#9660;</span></div>
          <div class="dropdown">
            <a class="dropdown-item" href="about.php">About Cosmos Bank</a>
            <a class="dropdown-item" href="about.php#leadership">Leadership Team</a>
            <a class="dropdown-item" href="about.php#awards">Awards & Recognition</a>
            <a class="dropdown-item" href="about.php#csr">CSR Initiatives</a>
          </div>
        </div>
        <div class="nav-item">
          <div class="nav-link <?= $page==='services'?'active':'' ?>">Services <span style="font-size:10px;">&#9660;</span></div>
          <div class="dropdown">
            <a class="dropdown-item" href="services.php#accounts">Savings Account</a>
            <a class="dropdown-item" href="services.php#accounts">Current Account</a>
            <a class="dropdown-item" href="services.php#deposits">Fixed Deposits</a>
            <a class="dropdown-item" href="services.php#digital">Digital Banking</a>
            <a class="dropdown-item" href="services.php#nri">NRI Services</a>
          </div>
        </div>
        <div class="nav-item">
          <a class="nav-link <?= $page==='loans'?'active':'' ?>" href="loans.php">Loans</a>
        </div>
        <div class="nav-item">
          <a class="nav-link <?= $page==='resources'?'active':'' ?>" href="resources.php">Resources</a>
        </div>
        <div class="nav-item">
          <a class="nav-link <?= $page==='contact'?'active':'' ?>" href="contact.php">Contact</a>
        </div>
      </nav>
      <div class="header-actions">
        <a href="netbanking.php" class="btn btn-outline btn-sm">Login</a>
        <a href="netbanking.php" class="btn btn-primary btn-sm">Net Banking</a>
      </div>
    </div>
  </div>
</header>
