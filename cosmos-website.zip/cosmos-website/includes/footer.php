<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
          <svg width="36" height="36" viewBox="0 0 44 44"><circle cx="22" cy="22" r="20" fill="none" stroke="#1d9a9a" stroke-width="2"/><circle cx="22" cy="22" r="8" fill="#0f6e6e"/></svg>
          <div class="brand-name" style="color:#fff;">Cosmos iBank</div>
        </div>
        <div class="footer-desc">Serving India with trust since 1906. A multistate scheduled bank with branches across India and international presence.</div>
        <div style="margin-top:16px;display:flex;gap:10px;">
          <span style="background:#1a3a3a;color:#8fb0b0;font-size:11px;padding:4px 10px;border-radius:4px;">FDIC Insured</span>
          <span style="background:#1a3a3a;color:#8fb0b0;font-size:11px;padding:4px 10px;border-radius:4px;">RBI Regulated</span>
        </div>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="services.php">Services</a>
        <a href="loans.php">Loans</a>
        <a href="resources.php">Resources</a>
        <a href="contact.php">Contact Us</a>
      </div>
      <div class="footer-col">
        <h4>Services</h4>
        <a href="services.php#accounts">Savings Account</a>
        <a href="services.php#accounts">Current Account</a>
        <a href="services.php#deposits">Fixed Deposits</a>
        <a href="services.php#digital">Mobile Banking</a>
        <a href="services.php#nri">NRI Services</a>
        <a href="loans.php">Personal Loans</a>
      </div>
      <div class="footer-col">
        <h4>Support</h4>
        <a href="resources.php#faq">FAQs</a>
        <a href="resources.php#forms">Download Forms</a>
        <a href="resources.php#rates">Interest Rates</a>
        <a href="contact.php">Grievance Redressal</a>
        <a href="contact.php">Fraud Reporting</a>
        <a href="#">Privacy Policy</a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2024 Cosmos Co-operative Bank Ltd. All rights reserved. Training-lab website — not a real financial institution.</p>
      <p>Registered Office: 269-A, Budhwar Peth, Pune - 411002, Maharashtra</p>
    </div>
  </div>
</footer>
